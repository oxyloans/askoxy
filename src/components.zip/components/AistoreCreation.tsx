import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FaShoppingCart } from "react-icons/fa";
import * as XLSX from "xlsx";
import {
  Table,
  Button,
  Modal,
  Input,
  Form,
  message,
  Switch,
  Checkbox,
  Space,
  Tag,
  Select,
  Empty,
  Spin,
  Image,
  Row,
  Col,
} from "antd";

import {
  EditOutlined,
  PlusOutlined,
  UsergroupAddOutlined,
  CopyOutlined,
  DeleteOutlined,
} from "@ant-design/icons";

import BASE_URL,{uploadurlwithId} from "../Config";
import type { FormInstance } from "antd/es/form";
import customerApi from "../utils/axiosInstances";

const PAGE_SIZE = 100;

interface Agent {
  agentId: string;
  assistantId: string;
  agentName: string;
  imageUrl: string | null;
  profileImageUrl?: string | null;

  agentStatus: "ACTIVE" | "INACTIVE";
  agentCreatorName: string | null;
}

interface Store {
  storeId: string;
  storeName: string;
  description: string;
  storeCreatedBy: string;
  storeImageUrl: string;
  aiStoreStatus: string;
  agentDetailsOnAdUser: Agent[];
  inactiveType: string;
  isCompanyStore?: boolean;
  companyName?: string | null;
}

const AgentStoreManager: React.FC = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const navigate = useNavigate();
  const [storeData, setStoreData] = useState<Store[]>([]);
  const [assistants, setAssistants] = useState<Agent[]>([]);
  const [lastId, setLastId] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [saving, setSaving] = useState<boolean>(false);
  const [isStoreModal, setIsStoreModal] = useState<boolean>(false);
  const [isAgentsModal, setIsAgentsModal] = useState<boolean>(false);
  const [isAgentsShowModal, setIsAgentsShowModal] = useState<boolean>(false);
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [refreshTrigger, setRefreshTrigger] = useState<number>(0);
  const [selectedAgents, setSelectedAgents] = useState<Agent[]>([]);
  const [selectedStore, setSelectedStore] = useState<Store | null>(null);
  const [agentSearch, setAgentSearch] = useState<string>("");
  const [isStoreConfirm, setIsStoreConfirm] = useState<boolean>(false);
  const [isAgentsConfirm, setIsAgentsConfirm] = useState<boolean>(false);

  const [form] = Form.useForm<{
    storeName: string;
    description: string;
    storeImageUrl: string;
    isCompanyStore: boolean;
    companyName?: string; // ✅ NEW
  }>();

  const accessToken: string = localStorage.getItem("token") || "";

  const getAuthHeader = (): { Authorization: string } => ({
    Authorization: `Bearer ${localStorage.getItem("token")}`,
  });

  // Dynamic base URL
  const isSandbox: boolean = window.location.href.includes("sandbox");
  const baseUrl: string = isSandbox
    ? "https://www.sandbox.askoxy.ai"
    : "https://www.askoxy.ai";

  const noAuthUrlPrefix: string = `${baseUrl}/ai-store/`;
  const filteredAssistants: Agent[] = assistants.filter((agent) =>
    agent.agentName?.toLowerCase().includes(agentSearch.toLowerCase())
  );

  const isValidAgent = (agent: any): boolean =>
    !!(
      agent &&
      agent.agentId &&
      agent.assistantId &&
      agent.agentName &&
      String(agent.agentId).trim() &&
      String(agent.assistantId).trim() &&
      String(agent.agentName).trim()
    );

  const getValidAgents = (agents?: any[]): Agent[] =>
    (Array.isArray(agents) ? agents : [])
      .filter(isValidAgent)
      .map((agent: any) => ({
        ...agent,
        agentId: String(agent.agentId),
        assistantId: String(agent.assistantId),
        agentName: String(agent.agentName).trim(),
        imageUrl: agent.imageUrl || null,
        profileImageUrl: agent.profileImageUrl || null,
        agentCreatorName: agent.agentCreatorName || null,
        agentStatus: agent.agentStatus === "ACTIVE" ? "ACTIVE" : "INACTIVE",
      }));


  // Slugify store name for clean URL
  const slugify = (text: string | undefined): string =>
    (text || "")
      .toLowerCase()
      .replace(/\s+/g, "-")
      .replace(/[^\w-]+/g, "")
      .replace(/--+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 30) || "store";

  // Copy to clipboard with fallback
  const handleCopy = (text: string): void => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(text)
        .then(() => {
          message.success("URL copied to clipboard!");
        })
        .catch(() => {
          fallbackCopy(text);
        });
    } else {
      fallbackCopy(text);
    }
  };

  const [isBulkUploadModal, setIsBulkUploadModal] = useState(false);
  const [bulkUploading, setBulkUploading] = useState(false);
  const [uploadForm] = Form.useForm();

  const userId = localStorage.getItem("userId");



  const isXlsxFile = (file: File) => {
    const lowerName = file.name.toLowerCase();
    return lowerName.endsWith(".xlsx") || lowerName.endsWith(".xls");
  };
const [bulkFile, setBulkFile] = useState<File | null>(null);
const fileInputRef = React.useRef<HTMLInputElement | null>(null);

const clearBulkUploadForm = () => {
  uploadForm.resetFields();
  setBulkFile(null);

  if (fileInputRef.current) {
    fileInputRef.current.value = "";
  }
};
  const validateExcelFormat = async (file: File): Promise<boolean> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          
          if (workbook.SheetNames.length === 0) {
            message.error("Excel file has no sheets");
            resolve(false);
            return;
          }

          const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
          const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });
          
          if (jsonData.length === 0) {
            message.error("Excel file is empty");
            resolve(false);
            return;
          }

          const headers = jsonData[0] as string[];
          const requiredHeaders = ['role', 'goal', 'purpose', 'agentName'];
          
          const hasValidHeaders = requiredHeaders.every(header => 
            headers.includes(header)
          );

          if (!hasValidHeaders) {
            message.error(`Invalid Excel format. Required headers: ${requiredHeaders.join(', ')}`);
            resolve(false);
            return;
          }

          if (jsonData.length < 2) {
            message.error("Excel file must contain at least one data row");
            resolve(false);
            return;
          }

          resolve(true);
        } catch (error) {
          message.error("Failed to read Excel file");
          resolve(false);
        }
      };
      reader.readAsArrayBuffer(file);
    });
  };

 const handleMultiAgentUpload = async (values: any) => {
  try {
    const storeId = values?.storeId;
    const view = values?.view;
    const file = bulkFile;

    if (!storeId) return message.error("Please select a store");
    if (!view) return message.error("Please select view");
    if (!file) return message.error("Please choose an Excel file");

    if (!isXlsxFile(file)) {
      return message.error("Only Excel files (.xlsx, .xls) are allowed");
    }

    const isValidFormat = await validateExcelFormat(file);
    if (!isValidFormat) return;

    if (!userId) {
      return message.error("UserId not found. Please login again.");
    }

    setBulkUploading(true);
    message.loading({
      content: "Uploading agents, please wait...",
      key: "bulkUpload",
      duration: 0,
    });

    const formData = new FormData();
    formData.append("storeId", storeId);
    formData.append("userId", userId);
    formData.append("view", view);
    formData.append("file", file);

    const res = await fetch(`${BASE_URL}/ai-service/agent/uploadMultiAgents1`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: formData,
    });

    if (!res.ok) {
      let errorMessage = "Upload failed. Please try again.";
      try {
        const errorData = await res.json();
        errorMessage = errorData?.message || errorMessage;
      } catch {}

      throw new Error(errorMessage);
    }

    message.success({
      content: "Agents uploaded successfully!",
      key: "bulkUpload",
      duration: 3,
    });

    clearBulkUploadForm();
    setIsBulkUploadModal(false);
    await fetchStores();
  } catch (err: any) {
    console.error("Upload error:", err);
    message.error({
      content: err?.message || "Failed to upload agents",
      key: "bulkUpload",
      duration: 4,
    });
  } finally {
    setBulkUploading(false);
  }
};

  const fallbackCopy = (text: string): void => {
    const textarea: HTMLTextAreaElement = document.createElement("textarea");
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    document.body.removeChild(textarea);
    message.success("URL copied!");
  };

  const fetchStores = async (): Promise<void> => {
    setLoading(true);
    try {
      const res = await customerApi.get(
        `${BASE_URL}/ai-service/agent/getAiStoreAllAgents`,
        {
          headers: { Authorization: `Bearer ${accessToken}` },
        }
      );

      const result: any = res.data;

     
      const data: any[] = Array.isArray(result)
        ? result
        : Array.isArray(result?.data)
        ? result.data
        : result?.data
        ? [result.data]
        : [result];

      const validStores: Store[] = data
        .filter((store: any) => store && store.storeId && store.userId === userId)
        .map((store: any) => ({
          ...store,
          agentDetailsOnAdUser: getValidAgents(store.agentDetailsOnAdUser),
        }));

     
      const getSortTime = (s: any) => {
        const val =
          s?.updatedAt ||
          s?.updatedDate ||
          s?.lastUpdatedAt ||
          s?.modifiedAt ||
          s?.createdAt ||
          s?.createdDate;

        const t = val ? new Date(val).getTime() : 0;
        return Number.isFinite(t) ? t : 0;
      };

      const sortedStores = [...validStores].sort((a: any, b: any) => {
        const tb = getSortTime(b);
        const ta = getSortTime(a);

        // first priority: latest timestamp
        if (tb !== ta) return tb - ta;

        // fallback: keep order as-is
        return 0;
      });

      setStoreData(sortedStores);

   
      if (selectedStore) {
        const updatedStore: Store | undefined = sortedStores.find(
          (s: Store) => s.storeId === selectedStore.storeId
        );
        if (updatedStore) {
          setSelectedStore(updatedStore);
        }
      }
    } catch (err) {
      message.error("Failed to load stores");
      setStoreData([]);
    } finally {
      setLoading(false);
    }
  };

const handleSaveStoreClick = async (): Promise<void> => {
  try {
    const values = await form.validateFields();

    const trimmedStoreName = values.storeName.trim().replace(/\s+/g, " ");
    form.setFieldsValue({ storeName: trimmedStoreName });

    if (isDuplicateStoreName(trimmedStoreName)) {
      message.error(
        `"${trimmedStoreName}" already exists. Store name must be unique.`
      );
      return;
    }

    setIsStoreConfirm(true);
  } catch (errorInfo) {
    console.log("Validation Failed:", errorInfo);
  }
};

  /** Load Assistants (cursor based) */
  const fetchAssistants = async (
    page: number = 1,
    append: boolean = false
  ): Promise<void> => {
    if (loading) return;

    setLoading(true);
    try {
      const url: string = `${BASE_URL}/ai-service/agent/getAllAssistants?limit=${PAGE_SIZE}${
        page > 1 && lastId ? `&after=${lastId}` : ""
      }`;

      const res = await customerApi.get(url, {
        headers: {
          ...getAuthHeader(),
          Accept: "application/json",
        },
      });

      const json: any = res.data;
      const rawList: any[] = json.data || [];

      const mapped: Agent[] = rawList.map((item: any) => ({
        agentId: item.agentId || item.assistantId,
        assistantId: item.assistantId || item.agentId,
        agentName: item.name || "Untitled Agent",
        imageUrl: item.imageUrl || null,

        agentStatus: item.agentStatus || "INACTIVE",
        agentCreatorName: item.agentCreatorName || null,
      }));

      setAssistants((prev: Agent[]) =>
        append ? [...prev, ...mapped] : mapped
      );
      setHasMore(json.hasMore === true);

      if (mapped.length > 0) {
        setLastId(rawList[rawList.length - 1].assistantId);
      }
    } catch (err) {
      message.error("Failed to load assistants");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStores();
    fetchAssistants(1, false);
  }, []);

  /** Change Agent Status */
  const handleStatusChange = (agent: Agent, storeId: string): void => {
    Modal.confirm({
      title: "Confirm Status Change",
      content: `Are you sure you want to set "${agent.agentName}" as ${
        agent.agentStatus === "ACTIVE" ? "Inactive" : "Active"
      }?`,
      okText: "Yes, Change",
      cancelText: "Cancel",
      okButtonProps: {
        style: { background: "#1ab394", borderColor: "#1ab394" },
      },
      onOk: () => updateAgentStatus(agent, storeId),
    });
  };

  const updateAgentStatus = async (
    agent: Agent,
    storeId: string
  ): Promise<void> => {
    try {
      const newStatus: "ACTIVE" | "INACTIVE" =
        agent.agentStatus === "ACTIVE" ? "INACTIVE" : "ACTIVE";

      const payload: {
        agentId: string;
        inactiveType: string;
        agentStatus: "ACTIVE" | "INACTIVE";
      } = {
        agentId: agent.agentId,
        agentStatus: newStatus,
        inactiveType: "STOREAGENT",
      };

      const res = await customerApi.post(
        `${BASE_URL}/ai-service/agent/activeInactiveStoreAgents`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      if (!res.data) throw new Error("Status update failed");

      message.success(`Agent status updated to ${newStatus}`);
      await fetchStores();
      setRefreshTrigger((prev: number) => prev + 1);
    } catch (err: any) {
      message.error(err.message || "Status update failed");
    }
  };

  /** Add More Assistants */
  const loadMore = (): void => {
    const nextPage: number = currentPage + 1;
    setCurrentPage(nextPage);
    fetchAssistants(nextPage, true);
  };
const normalizeStoreName = (name?: string): string =>
  (name || "").trim().replace(/\s+/g, " ").toLowerCase();

const isDuplicateStoreName = (storeName: string): boolean => {
  const currentName = normalizeStoreName(storeName);

  return storeData.some((store) => {
    const existingName = normalizeStoreName(store.storeName);

    // allow same name while editing same store
    if (isEditMode && selectedStore?.storeId === store.storeId) {
      return false;
    }

    return existingName === currentName;
  });
};
 const saveStore = async (): Promise<void> => {
  setSaving(true);
  try {
    const values = await form.validateFields();

    const trimmedStoreName = values.storeName.trim().replace(/\s+/g, " ");

    if (isDuplicateStoreName(trimmedStoreName)) {
      message.error(
        `"${trimmedStoreName}" already exists. Store name must be unique.`
      );
      setSaving(false);
      return;
    }

    const payload: any = isEditMode
      ? {
          storeId: selectedStore!.storeId,
          storeName: trimmedStoreName,
          description: values.description.trim(),
          storeCreatedBy: "USER",
          userId: userId,
          storeImageUrl: values.storeImageUrl,
          isCompanyStore: !!values.isCompanyStore,
          ...(values.isCompanyStore && {
            companyName: values.companyName?.trim(),
          }),
        }
      : {
          storeName: trimmedStoreName,
          description: values.description.trim(),
          storeCreatedBy: "USER",
          storeImageUrl: values.storeImageUrl,
          isCompanyStore: !!values.isCompanyStore,
          userId: userId,
          ...(values.isCompanyStore && {
            companyName: values.companyName?.trim(),
          }),
        };

    const res = await customerApi.patch(
      `${BASE_URL}/ai-service/agent/agentStoreCreation`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    if (!res.data) throw new Error("Failed to save store");

    message.success(
      isEditMode ? "Store updated successfully" : "Store created successfully"
    );

    setIsStoreModal(false);
    form.resetFields();
    fetchStores();
  } catch (err: any) {
    if (err.errorFields) return;
    message.error("Something went wrong");
  } finally {
    setSaving(false);
  }
};

const saveAgentsToStore = async (): Promise<void> => {
  if (!selectedStore) {
    message.error("Store not selected");
    return;
  }

  if (selectedAgents.length === 0) {
    message.error("Please select at least 1 agent");
    return;
  }

  const existingAgents = getValidAgents(selectedStore.agentDetailsOnAdUser);

  const duplicateAgents = selectedAgents.filter((selected) =>
    existingAgents.some(
      (existing) =>
        existing.agentId === selected.agentId ||
        existing.assistantId === selected.assistantId ||
        existing.agentName?.trim().toLowerCase() ===
          selected.agentName?.trim().toLowerCase()
    )
  );

  if (duplicateAgents.length > 0) {
    message.warning(
      `${duplicateAgents
        .map((a) => a.agentName)
        .join(", ")} already added in this AI Store. One agent can be added only once.`
    );
    return;
  }

  const payload = {
    storeId: selectedStore.storeId,
    storeName: selectedStore.storeName,
    storeImageUrl: selectedStore.storeImageUrl,
    agentDetailsOnAdUser: selectedAgents,
  };

  try {
    const res = await customerApi.post(
      `${BASE_URL}/ai-service/agent/saveAgentsInStore`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    if (!res.data) throw new Error("Failed to save agents");

    message.success("Agents added to store successfully");
    setIsAgentsModal(false);
    setIsAgentsConfirm(false);
    setSelectedAgents([]);
    setAgentSearch("");
    await fetchStores();
  } catch (err: any) {
    message.error(err.message || "Failed to save agents");
  }
};

  const toggleStoreStatus = (
    storeId: any,
    currentStatus: any,
    storeName: any
  ) => {
    const newStatus = currentStatus === "ACTIVE" ? "INACTIVE" : "ACTIVE";

    Modal.confirm({
      title: "Confirm Status Change",
      content: (
        <span>
          Are you sure you want to mark the store{" "}
          <strong style={{ color: "#008cba" }}>{storeName}</strong> as{" "}
          <strong
            style={{ color: newStatus === "ACTIVE" ? "#22C55E" : "#EF4444" }}
          >
            {newStatus}
          </strong>
          ?
        </span>
      ),
      okText: "Yes, Change",
      cancelText: "No",
      okButtonProps: {
        style: {
          background: newStatus === "ACTIVE" ? "#22C55E" : "#EF4444",
          borderColor: newStatus === "ACTIVE" ? "#22C55E" : "#EF4444",
        },
      },

      onOk: async () => {
        try {
          const payload = {
            storeId,
            aiStoreStatus: newStatus,
            inactiveType: "STORE",
          };

          const res = await customerApi.post(
            `${BASE_URL}/ai-service/agent/activeInactiveStoreAgents`,
            payload,
            {
              headers: {
                Authorization: `Bearer ${accessToken}`,
              },
            }
          );

          if (!res.data) throw new Error("Status update failed");

          message.success(
            `Store "${storeName}" successfully marked as ${newStatus}`
          );

          fetchStores();
        } catch (err: any) {
          message.error(err.message || "Failed to update store status");
        }
      },
    });
  };

  /** TABLE COLUMNS */
  const columns: any[] = [
    {
      title: "S.No",
      dataIndex: "sno",
      key: "sno",
      align: "center",
      render: (_: any, __: any, index: number) => index + 1,
    },
    {
      title: "Store Name",
      dataIndex: "storeName",
      key: "storeName",
      align: "center",
      render: (text: string) => <strong>{text || "-"}</strong>,
    },
    {
      title: "Created By",
      dataIndex: "storeCreatedBy",
      key: "storeCreatedBy",
      align: "center",
      render: (text: string) => <Tag color="blue">{text || "-"}</Tag>,
    },

    // ✅ NEW: show Company Store status
    {
      title: "Company Store",
      dataIndex: "isCompanyStore",
      key: "isCompanyStore",
      align: "center",
      render: (val: any) =>
        val ? <Tag color="green">YES</Tag> : <Tag color="default">NO</Tag>,
    },

    {
      title: "Description",
      dataIndex: "description",
      key: "description",
      render: (text: string) => (
        <div
          style={{
            maxWidth: 300,
            textAlign: "center",
            display: "-webkit-box",
            WebkitLineClamp: 5,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}
        >
          {text}
        </div>
      ),
      align: "center",
    },

    {
      title: <div style={{ textAlign: "center" }}>AI Store URL (Public)</div>,
      align: "center",
      render: (_: any, record: Store) => {
        const slug: string = slugify(record.storeName);
        const url: string = `${noAuthUrlPrefix}${slug}`;
        return (
          <Space direction="vertical" size={4}>
            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#008cba] text-md break-all"
            >
              {url}
            </a>
            <Button
              size="small"
              icon={<CopyOutlined />}
              onClick={() => handleCopy(url)}
            >
              Copy
            </Button>
          </Space>
        );
      },
    },
    {
      title: "Agents",
      key: "agents",
      align: "center",

      render: (_: any, record: Store) => {
        const agents: Agent[] = getValidAgents(record.agentDetailsOnAdUser);

        if (agents.length === 0) {
          return (
            <Empty
              image={Empty.PRESENTED_IMAGE_SIMPLE}
              description="No Agents"
              style={{ margin: "8px 0" }}
            />
          );
        }

        return (
          <Button
            type="link"
            size="small"
            style={{ color: "#008cba", fontWeight: 500 }}
            onClick={() => {
              setSelectedStore({
                ...record,
                agentDetailsOnAdUser: getValidAgents(record.agentDetailsOnAdUser),
              });
              setIsAgentsShowModal(true);
            }}
          >
            View {agents.length} Agent{agents.length > 1 ? "s" : ""}
          </Button>
        );
      },
    },
    {
      title: "Actions",
      align: "center",
      render: (_: any, record: Store) => (
        <Space direction="vertical" size="small" style={{ width: "90%" }}>
          <Button
            icon={<EditOutlined />}
            style={{
              background: "#1ab394",
              color: "#fff",
              border: "none",
              width: "100%",
            }}
            onClick={() => {
              setIsEditMode(true);
              setSelectedStore(record);

              form.setFieldsValue({
                storeName: record.storeName,
                description: record.description,
                storeImageUrl: record.storeImageUrl,
                isCompanyStore: !!record.isCompanyStore,
                companyName: record.companyName || undefined, // ✅ NEW
              });

              setIsStoreModal(true);
            }}
          >
            Edit Store
          </Button>

          <Button
            icon={<UsergroupAddOutlined />}
            style={{
              background: "#008cba",
              color: "#fff",
              border: "none",
              width: "100%",
            }}
            onClick={() => {
              setSelectedStore({
                ...record,
                agentDetailsOnAdUser: getValidAgents(record.agentDetailsOnAdUser),
              });
              setSelectedAgents([]);
              setAgentSearch("");
              setIsAgentsModal(true);
            }}
          >
            Add Agents
          </Button>

          <Button
            onClick={() =>
              toggleStoreStatus(
                record.storeId,
                record.aiStoreStatus,
                record.storeName
              )
            }
            style={{
              background:
                record.aiStoreStatus === "ACTIVE" ? "#22C14E" : "#ef4444",
              borderColor:
                record.aiStoreStatus === "ACTIVE" ? "#22C15E" : "#ef4444",
              color: "#fff",
              fontWeight: 600,
              letterSpacing: 0.5,
            }}
          >
            {record.aiStoreStatus === "ACTIVE" ? "Active" : "Inactive"}
          </Button>
        </Space>
      ),
    },
  ];

  const downloadExcelTemplate = () => {
    const data = [
      ["role", "goal", "purpose", "agentName"],
      ["student", "study_abroad", "usa_details", "USA-Agent"],
      ["parent", "loan_help", "education_loan", "Loan-Agent"],
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(data);

    worksheet["!cols"] = [{ wch: 18 }, { wch: 20 }, { wch: 22 }, { wch: 20 }];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Agents");

    XLSX.writeFile(workbook, "bulk-upload-agents-template.xlsx");
  };

  return (
    <div style={{ padding: "16px", background: "#fff", minHeight: "100vh" }}>
      {/* HEADER */}
      <div
        className="flex flex-col gap-4 mb-5 sm:flex-row sm:justify-between sm:items-center"
        style={{ marginBottom: "20px" }}
      >
        {/* Title - Left Side */}
        <div className="flex-1 min-w-0">
          <h1
            className="text-xl font-semibold text-gray-900 m-0 sm:text-2xl"
            style={{
              fontSize: "20px",
              fontWeight: "600",
              margin: 0,
              color: "#1a1a1a",
            }}
          >
            Agent AI Store Manager
          </h1>
        </div>

        {/* Buttons - Right Side */}
        <div className="flex flex-col gap-2 w-full sm:flex-row sm:w-auto sm:gap-3">
          <Button
            type="primary"
            icon={<PlusOutlined />}
            className="flex-1 h-10 font-medium sm:flex-none"
            style={{
              background: "#008cba",
              borderColor: "#008cba",
              height: "40px",
              fontWeight: "500",
            }}
            onClick={() => {
              setIsEditMode(false);
              form.resetFields();

              // ✅ default for create
              form.setFieldsValue({ isCompanyStore: false });

              setIsStoreModal(true);
            }}
          >
            Create AI Store
          </Button>

          {storeData.length > 0 && (
            <Button
              icon={<UsergroupAddOutlined />}
              className="flex-1 h-10 font-medium sm:flex-none"
              style={{
                background: "#ba4d00ff",
                borderColor: "#ba4d00ff",
                height: "40px",
                color: "#f7f7f7",
                fontWeight: "500",
              }}
              type="default"
              onClick={() => {
                clearBulkUploadForm();
                uploadForm.setFieldsValue({ view: "public" });
                setIsBulkUploadModal(true);
              }}
            >
              Bulk Upload Agents
            </Button>
          )}

          <Button
            type="primary"
            icon={<FaShoppingCart />}
            className="flex-1 h-10 font-medium sm:flex-none"
            style={{
              background: "#1ab394",
              borderColor: "#1ab394",
              height: "40px",
              fontWeight: "500",
            }}
            onClick={() => {
              navigate("/all-ai-stores");
            }}
          >
            Explore AI Stores
          </Button>
        </div>
      </div>

      <Modal
        open={isBulkUploadModal}
        title="Bulk Upload Agents"
        onCancel={() => {
          setIsBulkUploadModal(false);
          clearBulkUploadForm();
          uploadForm.resetFields();
        }}
        onOk={() => uploadForm.submit()}
        okText="Upload"
        confirmLoading={bulkUploading}
        width={720}
      >
        <Form
          form={uploadForm}
          layout="vertical"
          onFinish={(values) => {
            if (!bulkFile) {
              message.error("Please select an Excel file");
              return;
            }

            handleMultiAgentUpload(values);
          }}
          initialValues={{ view: "public" }}
        >
          <Row gutter={[12, 12]}>
            <Col xs={24} md={12}>
              <Form.Item
                name="storeId"
                label="Store"
                rules={[{ required: true, message: "Please select a store" }]}
                validateTrigger={["onChange", "onSubmit"]}
              >
                <Select
                  placeholder="Select Store"
                  showSearch
                  optionFilterProp="label"
                  allowClear
                >
                  {(storeData || []).map((s) => (
                    <Select.Option
                      key={s.storeId}
                      value={s.storeId}
                      label={s.storeName}
                    >
                      {s.storeName}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>

            <Col xs={24} md={12}>
              <Form.Item
                name="view"
                label="View"
                rules={[
                  { required: true, message: "Please select a view option" },
                ]}
                validateTrigger={["onChange", "onSubmit"]}
              >
                <Select>
                  <Select.Option value="public">public</Select.Option>
                  <Select.Option value="private">private</Select.Option>
                </Select>
              </Form.Item>
            </Col>

            <Col xs={24}>
              <Form.Item label="Excel Format (Required)">
                <div
                  style={{
                    marginBottom: 12,
                    padding: 12,
                    border: "1px solid #e5e7eb",
                    borderRadius: 8,
                    background: "#fafafa",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 10,
                    }}
                  >
                    <div style={{ fontWeight: 600, marginBottom: 8 }}>
                      Excel Format (Headers must be exact)
                    </div>

                    <Button type="default" onClick={downloadExcelTemplate}>
                      Download Template (.xlsx)
                    </Button>
                  </div>

                  <div style={{ overflowX: "auto" }}>
                    <table
                      style={{
                        width: "100%",
                        borderCollapse: "collapse",
                        minWidth: 520,
                      }}
                    >
                      <thead>
                        <tr>
                          {["role", "goal", "purpose", "agentName"].map((h) => (
                            <th
                              key={h}
                              style={{
                                border: "1px solid #d9d9d9",
                                padding: 8,
                                background: "#fff",
                                textAlign: "left",
                                whiteSpace: "nowrap",
                              }}
                            >
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td style={{ border: "1px solid #eee", padding: 8 }}>
                            student
                          </td>
                          <td style={{ border: "1px solid #eee", padding: 8 }}>
                            study_abroad
                          </td>
                          <td style={{ border: "1px solid #eee", padding: 8 }}>
                            usa_details
                          </td>
                          <td style={{ border: "1px solid #eee", padding: 8 }}>
                            USA-Agent
                          </td>
                        </tr>
                        <tr>
                          <td style={{ border: "1px solid #eee", padding: 8 }}>
                            parent
                          </td>
                          <td style={{ border: "1px solid #eee", padding: 8 }}>
                            loan_help
                          </td>
                          <td style={{ border: "1px solid #eee", padding: 8 }}>
                            education_loan
                          </td>
                          <td style={{ border: "1px solid #eee", padding: 8 }}>
                            Loan-Agent
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <div style={{ marginTop: 8, fontSize: 12, color: "#666" }}>
                    Note: Excel first row must be exactly:{" "}
                    <b> role, goal, purpose, agentName</b>
                    <br />
                    <span style={{ color: "#ff4d4f" }}>
                      ⚠️ Only Excel files (.xlsx, .xls) with correct format are
                      accepted
                    </span>
                  </div>
                </div>
              </Form.Item>

              <Form.Item label="Upload Excel File">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];

                    if (!file) {
                      setBulkFile(null);
                      return;
                    }

                    if (!isXlsxFile(file)) {
                      message.error(
                        "Only Excel files (.xlsx, .xls) are allowed",
                      );
                      e.target.value = "";
                      setBulkFile(null);
                      return;
                    }

                    const isValidFormat = await validateExcelFormat(file);
                    if (!isValidFormat) {
                      e.target.value = "";
                      setBulkFile(null);
                      return;
                    }

                    setBulkFile(file);
                    message.success(`"${file.name}" selected successfully`);
                  }}
                  style={{
                    width: "100%",
                    padding: "8px",
                    border: "1px dashed #d9d9d9",
                    borderRadius: "6px",
                    background: "#fafafa",
                  }}
                />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Modal>

      <Table<Store>
        columns={columns}
        dataSource={storeData}
        loading={loading}
        rowKey={(rec: Store) => rec.storeId}
        pagination={{
          pageSize: 10,
          showSizeChanger: true,
          showQuickJumper: true,
          showTotal: (total: number) => `Total ${total} stores`,
        }}
        bordered
        scroll={{ x: "true" }}
        style={{
          background: "#fff",
          borderRadius: "8px",
          overflow: "hidden",
        }}
      />

      {/* STORE MODAL */}
      <Modal
        title={
          <span style={{ fontSize: "18px", fontWeight: "600" }}>
            {isEditMode ? "Update AI Store" : "Create AI Store"}
          </span>
        }
        open={isStoreModal}
        onCancel={() => {
          setIsStoreModal(false);
          form.resetFields();
        }}
        confirmLoading={saving}
        footer={[
          <Button
            key="cancel"
            onClick={() => {
              setIsStoreModal(false);
              form.resetFields();
            }}
          >
            Cancel
          </Button>,

          <Button
            key="confirm"
            type="primary"
            style={{ background: "#1ab394", borderColor: "#1ab394" }}
            onClick={handleSaveStoreClick}
          >
            {isEditMode ? "Update Store" : "Create Store"}
          </Button>,
        ]}
        width={500}
      >
        <Form
          layout="vertical"
          form={form}
          style={{ marginTop: "20px" }}
          initialValues={{ isCompanyStore: false }} // ✅ default false
        >
          {/* Store Name */}
          <Form.Item
            name="storeName"
            label="Store Name"
            rules={[
              { required: true, message: "Store name is required" },
              {
                validator: (_, value) => {
                  if (value && isDuplicateStoreName(value)) {
                    return Promise.reject(
                      new Error(
                        "This store name already exists. Please use a unique name.",
                      ),
                    );
                  }
                  if (
                    value &&
                    value.trim().length > 0 &&
                    value.trim().length < 3
                  ) {
                    return Promise.reject(
                      new Error("Store name should be at least 3 characters"),
                    );
                  }
                  return Promise.resolve();
                },
              },
            ]}
            validateTrigger={["onBlur", "onSubmit"]}
          >
            <Input
              placeholder="Enter store name"
              size="large"
              onBlur={(e) => {
                const trimmed = e.target.value.trim();
                if (trimmed !== e.target.value) {
                  form.setFieldsValue({ storeName: trimmed });
                }
              }}
            />
          </Form.Item>

          {/* Description */}
          <Form.Item
            name="description"
            label="Description"
            rules={[
              { required: true, message: "Description is required" },
              {
                validator: (_, value) => {
                  if (value && value.trim().length === 0) {
                    return Promise.reject(
                      new Error("Please enter a valid description"),
                    );
                  }
                  if (
                    value &&
                    value.trim().length > 0 &&
                    value.trim().length < 10
                  ) {
                    return Promise.reject(
                      new Error("Description should be at least 10 characters"),
                    );
                  }
                  return Promise.resolve();
                },
              },
            ]}
            validateTrigger={["onBlur", "onSubmit"]}
          >
            <Input.TextArea
              rows={4}
              showCount
              maxLength={500}
              placeholder="Describe your store..."
              onBlur={(e) => {
                const trimmed = e.target.value.trim();
                if (trimmed !== e.target.value) {
                  form.setFieldsValue({ description: trimmed });
                }
              }}
            />
          </Form.Item>

          {/* ✅ NEW: Company Store Toggle */}
          <Form.Item
            name="isCompanyStore"
            label="Company Store"
            valuePropName="checked"
          >
            <Switch
              checkedChildren="ON"
              unCheckedChildren="OFF"
              onChange={(checked) => {
                if (!checked) form.setFieldsValue({ companyName: undefined });
              }}
            />
          </Form.Item>

          <Form.Item
            noStyle
            shouldUpdate={(prev, curr) =>
              prev.isCompanyStore !== curr.isCompanyStore
            }
          >
            {({ getFieldValue }) =>
              getFieldValue("isCompanyStore") ? (
                <Form.Item
                  name="companyName"
                  label="Company Name"
                  rules={[
                    {
                      required: true,
                      message: "Company name is required",
                    },
                    {
                      validator: (_, value) => {
                        if (value && value.trim().length === 0) {
                          return Promise.reject(
                            new Error("Please enter a valid company name"),
                          );
                        }
                        if (
                          value &&
                          value.trim().length > 0 &&
                          value.trim().length < 2
                        ) {
                          return Promise.reject(
                            new Error(
                              "Company name should be at least 2 characters",
                            ),
                          );
                        }
                        return Promise.resolve();
                      },
                    },
                  ]}
                  validateTrigger={["onBlur", "onSubmit"]}
                >
                  <Input
                    placeholder="Enter company name"
                    size="large"
                    onBlur={(e) => {
                      const trimmed = e.target.value.trim();
                      if (trimmed !== e.target.value) {
                        form.setFieldsValue({ companyName: trimmed });
                      }
                    }}
                  />
                </Form.Item>
              ) : null
            }
          </Form.Item>

          {/* STORE IMAGE */}
          <Form.Item
            label="Store Image"
            name="storeImageUrl"
            rules={[
              {
                required: !isEditMode,
                message: "Please upload an image",
              },
            ]}
          >
            <div>
              {form.getFieldValue("storeImageUrl") && (
                <div style={{ marginBottom: 8 }}>
                  <Image
                    src={form.getFieldValue("storeImageUrl")}
                    alt="Store"
                    width={100}
                    height={100}
                    style={{ objectFit: "cover", borderRadius: 8 }}
                  />
                </div>
              )}
              <input
                type="file"
                accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                onChange={async (e: React.ChangeEvent<HTMLInputElement>) => {
                  const file = e.target.files?.[0];
                  if (!file) return;

                  const allowedTypes = [
                    "image/jpeg",
                    "image/png",
                    "image/webp",
                  ];
                  const allowedExtensions = [".jpg", ".jpeg", ".png", ".webp"];

                  const fileName = file.name.toLowerCase();
                  const isValidType = allowedTypes.includes(file.type);
                  const isValidExtension = allowedExtensions.some((ext) =>
                    fileName.endsWith(ext),
                  );

                  if (!isValidType || !isValidExtension) {
                    message.error(
                      "Only JPG, JPEG, PNG, or WEBP image files are allowed.",
                    );
                    e.target.value = "";
                    form.setFieldsValue({ storeImageUrl: undefined });
                    return;
                  }

                  try {
                    const formData = new FormData();
                    formData.append("file", file);

                    const response = await customerApi.post(
                      `https://meta.oxyloans.com/api/upload-service/upload?id=45880e62-acaf-4645-a83e-d1c8498e923e&fileType=aadhar`,
                      formData,
                      {
                        headers: {
                          "Content-Type": "multipart/form-data",
                          Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
                        },
                      },
                    );

                    form.setFieldsValue({
                      storeImageUrl: response.data.documentPath,
                    });

                    form.validateFields(["storeImageUrl"]);
                    message.success("Image uploaded successfully!");
                  } catch (error) {
                    console.error("Upload error:", error);
                    message.error("Failed to upload image. Please try again.");
                    e.target.value = "";
                  }
                }}
                style={{
                  width: "100%",
                  padding: "8px",
                  border: "1px dashed #d9d9d9",
                  borderRadius: "6px",
                  cursor: "pointer",
                }}
              />
            </div>
          </Form.Item>
        </Form>
      </Modal>

      {/* STORE CONFIRMATION */}
      <Modal
        open={isStoreConfirm}
        title="Confirm Store Details"
        onCancel={() => setIsStoreConfirm(false)}
        footer={[
          <Button key="no" onClick={() => setIsStoreConfirm(false)}>
            Cancel
          </Button>,
          <Button
            key="yes"
            type="primary"
            style={{ background: "#1ab394", borderColor: "#1ab394" }}
            loading={saving}
            onClick={() => {
              setIsStoreConfirm(false);
              saveStore();
            }}
          >
            Confirm Save
          </Button>,
        ]}
      >
        <Space direction="vertical" style={{ width: "100%" }}>
          <p>
            <strong>Store Name:</strong> {form.getFieldValue("storeName")}
          </p>
          <p>
            <strong>Description:</strong> {form.getFieldValue("description")}
          </p>
          <p>
            <strong>Company Store:</strong>{" "}
            {form.getFieldValue("isCompanyStore") ? "Yes" : "No"}
          </p>
          {form.getFieldValue("storeImageUrl") && (
            <div>
              <strong>Store Image:</strong>
              <br />
              <Image
                width={120}
                src={form.getFieldValue("storeImageUrl") as string}
                alt="Store preview"
                style={{ marginTop: 8, borderRadius: 8 }}
                fallback="https://via.placeholder.com/120?text=No+Image"
              />
            </div>
          )}
        </Space>
      </Modal>

      {/* VIEW & MANAGE AGENTS MODAL */}
      <Modal
        title={
          <span
            style={{ fontSize: "18px", fontWeight: "600", color: "#1a1a1a" }}
          >
            Agents in Store:{" "}
            <strong style={{ color: "#008cba" }}>
              {selectedStore?.storeName}
            </strong>
          </span>
        }
        open={isAgentsShowModal}
        onCancel={() => {
          setIsAgentsShowModal(false);
          setSelectedStore(null);
        }}
        width={800}
        key={`${selectedStore?.storeId ?? ""}_${refreshTrigger}`}
        bodyStyle={{ padding: "20px" }}
        footer={null}
      >
        {selectedStore && (
          <Table<Agent>
            dataSource={getValidAgents(selectedStore.agentDetailsOnAdUser)}
            rowKey={(agent) => agent.agentId || agent.assistantId || agent.agentName}
            pagination={false}
            bordered
            scroll={{ x: "true" }}
            size="middle"
            style={{ marginTop: 16 }}
            columns={[
              {
                title: <strong>S.No</strong>,
                key: "sno",
                width: 70,
                align: "center",
                render: (_: any, __: any, index: number) => (
                  <span style={{ fontWeight: 600, color: "#008cba" }}>
                    {index + 1}
                  </span>
                ),
              },
              {
                title: <strong>Agent Id</strong>,
                dataIndex: "agentId",
                key: "agentId",
                align: "center",
                render: (text: string) => (
                  <span style={{ fontWeight: 500 }}>{text ? text.slice(-4) : "—"}</span>
                ),
              },
              {
                title: <strong>Agent Name</strong>,
                dataIndex: "agentName",
                key: "agentName",
                align: "center",
                render: (text: string) => (
                  <span style={{ fontWeight: 500 }}>
                    {text || "Unnamed Agent"}
                  </span>
                ),
              },
              {
                title: <strong>Agent Image</strong>,
                dataIndex: "profileImageUrl",
                key: "profileImageUrl",
                align: "center",
                render: (url: string | null) => {
                  if (!url || url === "null" || url === "undefined") {
                    return <div style={{ textAlign: "center", color: "#999", fontSize: 12 }}>No Image</div>;
                  }
                  const src = url.startsWith("http")
                    ? url
                    : `https://askoxy.s3.ap-south-1.amazonaws.com${url}`;
                  return (
                    <div style={{ textAlign: "center" }}>
                      <Image
                        width={50}
                        height={50}
                        src={src}
                        alt="agent image"
                        style={{ objectFit: "cover", borderRadius: 4 }}
                        fallback="https://via.placeholder.com/50?text=N/A"
                      />
                    </div>
                  );
                },
              },
              {
                title: <strong>Status</strong>,
                key: "status",
                width: 140,
                align: "center",
                render: (_: any, agent: Agent) => (
                  <Switch
                    checked={agent.agentStatus === "ACTIVE"}
                    checkedChildren="Active"
                    unCheckedChildren="Inactive"
                    style={{
                      backgroundColor:
                        agent.agentStatus === "ACTIVE" ? "#1ab394" : "#d9d9d9",
                    }}
                    onChange={() =>
                      handleStatusChange(agent, selectedStore.storeId)
                    }
                  />
                ),
              },
            ]}
          />
        )}

        {(!selectedStore?.agentDetailsOnAdUser ||
          getValidAgents(selectedStore.agentDetailsOnAdUser).length === 0) && (
          <Empty
            description="No agents added to this store yet"
            style={{ margin: "40px 0" }}
          />
        )}
      </Modal>

      {/* ADD AGENTS MODAL */}
      <Modal
        title={
          <span style={{ fontSize: "18px", fontWeight: "600" }}>
            Add Agents to "{selectedStore?.storeName || ""}"
          </span>
        }
        open={isAgentsModal}
        onCancel={() => {
          setIsAgentsModal(false);
          setSelectedAgents([]);
          setAgentSearch("");
        }}
        onOk={saveAgentsToStore}
        footer={[
          <Button
            key="cancel"
            onClick={() => {
              setIsAgentsModal(false);
              setSelectedAgents([]);
            }}
          >
            Cancel
          </Button>,
          <Button
            key="confirm"
            type="primary"
            disabled={selectedAgents.length === 0}
            style={{ background: "#1ab394", borderColor: "#1ab394" }}
            onClick={() => setIsAgentsConfirm(true)}
          >
            Add {selectedAgents.length} Agents
          </Button>,
        ]}
        okButtonProps={{
          style: {
            background: "#1ab394",
            borderColor: "#1ab394",
            height: "38px",
          },
          disabled: selectedAgents.length === 0,
        }}
        cancelButtonProps={{
          style: { height: "38px" },
        }}
        width={600}
      >
        <div style={{ marginTop: "12px" }}>
          <Input.Search
            allowClear
            placeholder="Search agents by name..."
            value={agentSearch}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
              setAgentSearch(e.target.value)
            }
            style={{ marginBottom: "12px" }}
          />

          <div
            style={{
              marginBottom: "12px",
              padding: "8px 12px",
              background: "#f0f5ff",
              borderRadius: "4px",
              fontSize: "13px",
              color: "#1890ff",
            }}
          >
            {selectedAgents.length} agent
            {selectedAgents.length !== 1 ? "s" : ""} selected
          </div>

          <div
            style={{
              maxHeight: "300px",
              overflowY: "auto",
              border: "1px solid #e8e8e8",
              padding: "12px",
              borderRadius: "6px",
              background: "#fafafa",
            }}
          >
            {loading && assistants.length === 0 ? (
              <div style={{ textAlign: "center", padding: "40px" }}>
                <Spin tip="Loading agents..." />
              </div>
            ) : filteredAssistants.length === 0 ? (
              <Empty description="No agents available" />
            ) : (
              filteredAssistants.map((agent: Agent) => {
                const isSelected: boolean = selectedAgents.some(
                  (x: Agent) => x.agentId === agent.agentId,
                );
                return (
                  <div
                    key={agent.agentId}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "12px",
                      marginBottom: "10px",
                      padding: "10px 12px",
                      background: "#fff",
                      borderRadius: "6px",
                      border: `1px solid ${isSelected ? "#1ab394" : "#e8e8e8"}`,
                      cursor: "pointer",
                      transition: "all 0.2s",
                      ...(isSelected && { background: "#f0f9f4" }),
                    }}
                    onClick={(e: React.MouseEvent<HTMLDivElement>) => {
                      const target = e.target as HTMLElement;

                      // ✅ If user clicked on checkbox/label/span inside checkbox, do nothing here
                      // (checkbox onChange will handle it)
                      if (
                        target.closest(".ant-checkbox-wrapper") ||
                        target.closest(".ant-checkbox")
                      ) {
                        return;
                      }

                      // ✅ Otherwise: clicking on name / image / row toggles selection
                      setSelectedAgents((prev: Agent[]) =>
                        isSelected
                          ? prev.filter(
                              (x: Agent) => x.agentId !== agent.agentId,
                            )
                          : [...prev, agent],
                      );
                    }}
                    onMouseEnter={(e: React.MouseEvent<HTMLDivElement>) => {
                      if (!isSelected) {
                        (e.currentTarget as HTMLElement).style.borderColor =
                          "#1ab394";
                        (e.currentTarget as HTMLElement).style.boxShadow =
                          "0 2px 8px rgba(26,179,148,0.15)";
                      }
                    }}
                    onMouseLeave={(e: React.MouseEvent<HTMLDivElement>) => {
                      if (!isSelected) {
                        (e.currentTarget as HTMLElement).style.borderColor =
                          "#e8e8e8";
                        (e.currentTarget as HTMLElement).style.boxShadow =
                          "none";
                      }
                    }}
                  >
                    <Checkbox
                      checked={isSelected}
                      onChange={(e: any) => {
                        e.stopPropagation();
                        setSelectedAgents((prev: Agent[]) =>
                          isSelected
                            ? prev.filter(
                                (x: Agent) => x.agentId !== agent.agentId,
                              )
                            : [...prev, agent],
                        );
                      }}
                    />
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "12px",
                        flex: 1,
                      }}
                    >
                      {agent.imageUrl ? (
                        <img
                          src={agent.imageUrl}
                          alt={agent.agentName}
                          style={{
                            width: 32,
                            height: 32,
                            borderRadius: "50%",
                            objectFit: "cover",
                          }}
                        />
                      ) : (
                        <div
                          style={{
                            width: 32,
                            height: 32,
                            borderRadius: "50%",
                            background: "#ddd",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            fontSize: "12px",
                            color: "#999",
                          }}
                        >
                          {agent.agentName?.[0]?.toUpperCase() || "?"}
                        </div>
                      )}
                      <span style={{ fontWeight: "500", fontSize: "14px" }}>
                        {agent.agentName}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {hasMore && (
            <div style={{ marginTop: "16px", textAlign: "center" }}>
              <Button
                onClick={loadMore}
                loading={loading}
                style={{ height: "38px" }}
              >
                Load More Agents
              </Button>
            </div>
          )}
        </div>
      </Modal>

      {/* AGENTS CONFIRMATION */}
      <Modal
        open={isAgentsConfirm}
        title="Confirm Agents Selection"
        onCancel={() => setIsAgentsConfirm(false)}
        footer={[
          <Button key="no" onClick={() => setIsAgentsConfirm(false)}>
            Cancel
          </Button>,
          <Button
            key="yes"
            type="primary"
            style={{ background: "#1ab394", borderColor: "#1ab394" }}
            onClick={() => {
              setIsAgentsConfirm(false);
              saveAgentsToStore();
            }}
          >
            Confirm Save
          </Button>,
        ]}
      >
        <p>
          <strong>Total Selected Agents:</strong> {selectedAgents.length}
        </p>

        <Table<Agent>
          dataSource={selectedAgents}
          rowKey={(agent) => agent.agentId || agent.assistantId || agent.agentName}
          pagination={false}
          bordered
          columns={[
            {
              title: "S.No",
              render: (_: any, __: any, index: number) => index + 1,
              align: "center",
              width: 70,
            },
            {
              title: "Agent ID",
              dataIndex: "agentId",
              align: "center",
              render: (id: string) => id?.slice(-4),
            },
            {
              title: "Agent Name",
              dataIndex: "agentName",
              align: "center",
            },
          ]}
        />
      </Modal>
    </div>
  );
};

export default AgentStoreManager;
